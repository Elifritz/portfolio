﻿-- Database: "Deer_Road_Database"

-- DROP DATABASE "Deer_Road_Database";

CREATE DATABASE "Deer_Road_Database"
  WITH OWNER = postgres
       ENCODING = 'UTF8'
       TABLESPACE = pg_default
       LC_COLLATE = 'English_United States.1252'
       LC_CTYPE = 'English_United States.1252'
       CONNECTION LIMIT = -1;

ALTER DATABASE "Deer_Road_Database"
  SET search_path = "$user", public, topology;

